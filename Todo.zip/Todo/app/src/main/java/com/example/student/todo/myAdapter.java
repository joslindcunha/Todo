package com.example.student.todo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.student.todo.R;

import java.util.ArrayList;

/**
 * Created by student on 3/28/18.
 */

public class myAdapter extends BaseAdapter
{
    ArrayList<String> list= new ArrayList<String>();
    Context ctx;
    LayoutInflater inflater;
    public myAdapter(ArrayList<String> list, Context ctx)
    {
        this.list=list;
        this.ctx=ctx;
        inflater=LayoutInflater.from(ctx);

    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup parent) {
        View cview;
        cview = inflater.inflate(R.layout.row,parent,false);
        TextView tv=cview.findViewById(R.id.tv);
        tv.setText(list.get(i));
        Button b1 = cview.findViewById(R.id.bt22);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.remove(i);
                notifyDataSetChanged();
            }
        });
        return cview;
    }
}
