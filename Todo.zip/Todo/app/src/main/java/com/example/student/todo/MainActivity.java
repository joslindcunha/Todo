package com.example.student.todo;
 
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
 
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
 
public class MainActivity extends AppCompatActivity {
    ListView listview;
    ArrayList<String> list=new ArrayList<String>();
    Button btn,bt2;
    EditText et;
 
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview=findViewById(R.id.list);
 
        btn=findViewById(R.id.bt1);
        et=findViewById(R.id.et1);
        bt2=findViewById(R.id.bt22);
 
        final String MyPREFERENCES = "MyPrefs" ;
        final String Name = "nameKey";
 
        final SharedPreferences sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        Set<String> set = sharedpreferences.getStringSet(Name, null);
        if(set!=null)
        list=new ArrayList<String>(set);
        final myAdapter adap=new myAdapter(list,this);
        listview.setAdapter(adap);
 
 
//                list.add("elem1");
//        list.add("elem2");
//        list.add("elem3");
//        list.add("elem4");
//        list.add("elem5");
 
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
 
                String s=et.getText().toString();
                if(s.isEmpty())
                    return;
                list.add(s);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                Set<String> set = new HashSet<>();
                set.addAll(list);
                editor.putStringSet(Name, set);
                editor.apply();
 
                adap.notifyDataSetChanged();
                et.setText("");
 
 
            }
        });
//        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                list.remove(i);
//                adap.notifyDataSetChanged();
//            }
//        });
    }
}